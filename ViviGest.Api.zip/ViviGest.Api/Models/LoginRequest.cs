﻿namespace ViviGest.Api.Models
{
    public class LoginRequest
    {
        public string Username { get; set; } = string.Empty; // correo
        public string Password { get; set; } = string.Empty;
    }
}
