﻿namespace ViviGest.Api.Dtos
{
    public class RegistrarResidenteDto : RegistrarUsuarioDto
    {
        public Guid IdUnidad { get; set; }
    }
}
